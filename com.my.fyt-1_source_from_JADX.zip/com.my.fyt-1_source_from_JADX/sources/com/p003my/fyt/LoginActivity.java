package com.p003my.fyt;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

/* renamed from: com.my.fyt.LoginActivity */
public class LoginActivity extends Activity {
    private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
    /* access modifiers changed from: private */
    public FirebaseAuth aut;
    private Button button1;
    private Button button2;
    /* access modifiers changed from: private */
    public EditText edittext1;
    /* access modifiers changed from: private */
    public EditText edittext2;
    private DatabaseReference fyt_for = this._firebase.getReference("userid");
    /* access modifiers changed from: private */
    public DatabaseReference fyt_form = this._firebase.getReference("username");
    /* access modifiers changed from: private */

    /* renamed from: i */
    public Intent f19i = new Intent();
    private LinearLayout linear1;
    private LinearLayout linear2;
    private ArrayList<HashMap<String, Object>> log = new ArrayList<>();
    private ArrayList<HashMap<String, Object>> maps = new ArrayList<>();
    /* access modifiers changed from: private */
    public HashMap<String, Object> sav = new HashMap<>();
    private TextView textview1;
    private TextView textview2;
    private TextView textview3;
    /* access modifiers changed from: private */
    public SharedPreferences user;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C0526R.layout.login);
        initialize();
        initializeLogic();
    }

    private void initialize() {
        this.linear1 = (LinearLayout) findViewById(C0526R.C0528id.linear1);
        this.linear2 = (LinearLayout) findViewById(C0526R.C0528id.linear2);
        this.button1 = (Button) findViewById(C0526R.C0528id.button1);
        this.textview3 = (TextView) findViewById(C0526R.C0528id.textview3);
        this.button2 = (Button) findViewById(C0526R.C0528id.button2);
        this.textview1 = (TextView) findViewById(C0526R.C0528id.textview1);
        this.edittext1 = (EditText) findViewById(C0526R.C0528id.edittext1);
        this.textview2 = (TextView) findViewById(C0526R.C0528id.textview2);
        this.edittext2 = (EditText) findViewById(C0526R.C0528id.edittext2);
        this.aut = FirebaseAuth.getInstance();
        this.user = getSharedPreferences("user", 0);
        this.button1.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (LoginActivity.this.edittext1.getText().toString().equals("") || LoginActivity.this.edittext2.getText().toString().equals("")) {
                    LoginActivity.this.showMessage("Fields are Empty");
                } else {
                    LoginActivity.this.aut.signInWithEmailAndPassword(LoginActivity.this.edittext1.getText().toString(), LoginActivity.this.edittext2.getText().toString()).addOnCompleteListener((Activity) LoginActivity.this, (OnCompleteListener<TResult>) new OnCompleteListener<AuthResult>() {
                        public void onComplete(Task<AuthResult> task) {
                            Boolean valueOf = Boolean.valueOf(task.isSuccessful());
                            if (task.getException() != null) {
                                task.getException().getMessage();
                            }
                            if (valueOf.booleanValue()) {
                                LoginActivity.this.f19i.setClass(LoginActivity.this.getApplicationContext(), FormActivity.class);
                                LoginActivity.this.startActivity(LoginActivity.this.f19i);
                            } else {
                                LoginActivity.this.showMessage("Please check the username and password!! And try again.");
                            }
                            LoginActivity.this.user.edit().putString("profil", LoginActivity.this.edittext1.getText().toString()).commit();
                        }
                    });
                }
                LoginActivity.this.f19i.putExtra("uid", LoginActivity.this.edittext1.getText().toString());
                LoginActivity.this.fyt_form.push().updateChildren(LoginActivity.this.sav);
            }
        });
        this.button2.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                LoginActivity.this.f19i.setClass(LoginActivity.this.getApplicationContext(), SignupActivity.class);
                LoginActivity.this.startActivity(LoginActivity.this.f19i);
            }
        });
    }

    private void initializeLogic() {
    }

    /* access modifiers changed from: private */
    public void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, 0).show();
    }

    private int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    private int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    private int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList<Double> arrayList = new ArrayList<>();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf((double) checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    private float getDip(int i) {
        return TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    private int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    private int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
