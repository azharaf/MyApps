package com.p003my.fyt;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.DownloadListener;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Random;

/* renamed from: com.my.fyt.MainActivity */
public class MainActivity extends Activity {
    private Button button1;
    private Button button2;
    private Button button3;
    private Button button4;
    private Builder exit;
    /* access modifiers changed from: private */

    /* renamed from: i */
    public Intent f20i = new Intent();
    private LinearLayout linear1;

    /* renamed from: n */
    private double f21n = 0.0d;
    /* access modifiers changed from: private */
    public WebView webview1;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C0526R.layout.main);
        initialize();
        initializeLogic();
    }

    private void initialize() {
        this.linear1 = (LinearLayout) findViewById(C0526R.C0528id.linear1);
        this.webview1 = (WebView) findViewById(C0526R.C0528id.webview1);
        this.webview1.getSettings().setJavaScriptEnabled(true);
        this.webview1.getSettings().setSupportZoom(true);
        this.webview1.setWebViewClient(new WebViewClient() {
            public void onPageStarted(WebView webView, String str, Bitmap bitmap) {
                super.onPageStarted(webView, str, bitmap);
            }

            public void onPageFinished(WebView webView, String str) {
                super.onPageFinished(webView, str);
            }
        });
        this.button1 = (Button) findViewById(C0526R.C0528id.button1);
        this.button2 = (Button) findViewById(C0526R.C0528id.button2);
        this.button3 = (Button) findViewById(C0526R.C0528id.button3);
        this.button4 = (Button) findViewById(C0526R.C0528id.button4);
        this.exit = new Builder(this);
        this.button1.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MainActivity.this.webview1.loadUrl("https://sites.google.com/site/feelyourtalent/");
            }
        });
        this.button2.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MainActivity.this.webview1.loadUrl("https://sites.google.com/site/feelyourtalent/classroom-pictures");
            }
        });
        this.button3.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MainActivity.this.f20i.setClass(MainActivity.this.getApplicationContext(), ApplyActivity.class);
                MainActivity.this.startActivity(MainActivity.this.f20i);
            }
        });
        this.button4.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                MainActivity.this.webview1.loadUrl("https://sites.google.com/site/feelyourtalent/about-me");
            }
        });
    }

    private void initializeLogic() {
        this.f20i.setClass(getApplicationContext(), FlashActivity.class);
        startActivity(this.f20i);
        this.webview1.setDownloadListener(new DownloadListener() {
            public void onDownloadStart(String str, String str2, String str3, String str4, long j) {
                Intent intent = new Intent("android.intent.action.VIEW");
                intent.setData(Uri.parse(str));
                MainActivity.this.startActivity(intent);
            }
        });
        this.webview1.loadUrl("https://sites.google.com/site/feelyourtalent/");
    }

    public void onBackPressed() {
        if (this.webview1.canGoBack()) {
            this.webview1.goBack();
            return;
        }
        this.exit.setTitle("Exit ??");
        this.exit.setMessage("Do you want to exit from here??");
        this.exit.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                MainActivity.this.finish();
            }
        });
        this.exit.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        this.exit.create().show();
    }

    private void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, 0).show();
    }

    private int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    private int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    private int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList<Double> arrayList = new ArrayList<>();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf((double) checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    private float getDip(int i) {
        return TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    private int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    private int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
