package com.p003my.fyt;

import android.app.Activity;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

/* renamed from: com.my.fyt.FlashActivity */
public class FlashActivity extends Activity {
    private Timer _timer = new Timer();

    /* renamed from: n */
    private double f13n = 0.0d;

    /* renamed from: t */
    private TimerTask f14t;
    private ScrollView vscroll2;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C0526R.layout.flash);
        initialize();
        initializeLogic();
    }

    private void initialize() {
        this.vscroll2 = (ScrollView) findViewById(C0526R.C0528id.vscroll2);
    }

    private void initializeLogic() {
        this.f14t = new TimerTask() {
            public void run() {
                FlashActivity.this.runOnUiThread(new Runnable() {
                    public void run() {
                        FlashActivity.this.finish();
                    }
                });
            }
        };
        this._timer.schedule(this.f14t, 3000);
        this.f13n += 1.0d;
    }

    private void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, 0).show();
    }

    private int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    private int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    private int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList<Double> arrayList = new ArrayList<>();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf((double) checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    private float getDip(int i) {
        return TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    private int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    private int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
