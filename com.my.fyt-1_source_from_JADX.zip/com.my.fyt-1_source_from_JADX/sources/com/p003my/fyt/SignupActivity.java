package com.p003my.fyt;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

/* renamed from: com.my.fyt.SignupActivity */
public class SignupActivity extends Activity {
    private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
    /* access modifiers changed from: private */
    public FirebaseAuth aut;
    private Button button1;
    /* access modifiers changed from: private */
    public EditText edittext1;
    /* access modifiers changed from: private */
    public EditText edittext2;
    /* access modifiers changed from: private */
    public DatabaseReference fyt_for = this._firebase.getReference("userid");
    /* access modifiers changed from: private */

    /* renamed from: i */
    public Intent f22i = new Intent();
    private LinearLayout linear3;
    private LinearLayout linear4;
    private TextView textview3;
    private TextView textview4;
    private TextView textview5;
    private TextView textview9;
    /* access modifiers changed from: private */
    public HashMap<String, Object> user = new HashMap<>();

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(C0526R.layout.signup);
        initialize();
        initializeLogic();
    }

    private void initialize() {
        this.textview3 = (TextView) findViewById(C0526R.C0528id.textview3);
        this.linear3 = (LinearLayout) findViewById(C0526R.C0528id.linear3);
        this.linear4 = (LinearLayout) findViewById(C0526R.C0528id.linear4);
        this.button1 = (Button) findViewById(C0526R.C0528id.button1);
        this.textview4 = (TextView) findViewById(C0526R.C0528id.textview4);
        this.edittext1 = (EditText) findViewById(C0526R.C0528id.edittext1);
        this.textview5 = (TextView) findViewById(C0526R.C0528id.textview5);
        this.edittext2 = (EditText) findViewById(C0526R.C0528id.edittext2);
        this.textview9 = (TextView) findViewById(C0526R.C0528id.textview9);
        this.aut = FirebaseAuth.getInstance();
        this.button1.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (SignupActivity.this.edittext1.getText().toString().equals("") || SignupActivity.this.edittext2.getText().toString().equals("")) {
                    SignupActivity.this.showMessage("Fields are empty..");
                } else {
                    SignupActivity.this.aut.createUserWithEmailAndPassword(SignupActivity.this.edittext1.getText().toString(), SignupActivity.this.edittext2.getText().toString()).addOnCompleteListener((Activity) SignupActivity.this, (OnCompleteListener<TResult>) new OnCompleteListener<AuthResult>() {
                        public void onComplete(Task<AuthResult> task) {
                            Boolean valueOf = Boolean.valueOf(task.isSuccessful());
                            String str = task.getException() != null ? task.getException().getMessage() : "";
                            if (valueOf.booleanValue()) {
                                SignupActivity.this.f22i.setClass(SignupActivity.this.getApplicationContext(), LoginActivity.class);
                                SignupActivity.this.startActivity(SignupActivity.this.f22i);
                                SignupActivity.this.finish();
                            } else {
                                SignupActivity.this.showMessage(str);
                            }
                            SignupActivity.this.user = new HashMap();
                            SignupActivity.this.user.put("uid", SignupActivity.this.edittext1.getText().toString());
                            SignupActivity.this.fyt_for.push().updateChildren(SignupActivity.this.user);
                        }
                    });
                }
            }
        });
    }

    private void initializeLogic() {
    }

    public void onBackPressed() {
        if (this.edittext1.getText().toString().equals("") || this.edittext2.getText().toString().equals("")) {
            showMessage("fields are empty, not signed up..");
        }
        this.f22i.setClass(getApplicationContext(), LoginActivity.class);
        startActivity(this.f22i);
        finish();
    }

    /* access modifiers changed from: private */
    public void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, 0).show();
    }

    private int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    private int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    private int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList<Double> arrayList = new ArrayList<>();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf((double) checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    private float getDip(int i) {
        return TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    private int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    private int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
