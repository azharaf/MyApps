package com.android.support;

import com.p003my.fyt.C0526R;

/* renamed from: com.android.support.R */
public final class C0124R {

    /* renamed from: com.android.support.R$attr */
    public static final class attr {
        public static int buttonSize = C0526R.attr.buttonSize;
        public static int circleCrop = C0526R.attr.circleCrop;
        public static int colorScheme = C0526R.attr.colorScheme;
        public static int imageAspectRatio = C0526R.attr.imageAspectRatio;
        public static int imageAspectRatioAdjust = C0526R.attr.imageAspectRatioAdjust;
        public static int scopeUris = C0526R.attr.scopeUris;
    }

    /* renamed from: com.android.support.R$color */
    public static final class color {
        public static int common_google_signin_btn_text_dark = C0526R.color.common_google_signin_btn_text_dark;
        public static int common_google_signin_btn_text_dark_default = C0526R.color.common_google_signin_btn_text_dark_default;
        public static int common_google_signin_btn_text_dark_disabled = C0526R.color.common_google_signin_btn_text_dark_disabled;
        public static int common_google_signin_btn_text_dark_focused = C0526R.color.common_google_signin_btn_text_dark_focused;
        public static int common_google_signin_btn_text_dark_pressed = C0526R.color.common_google_signin_btn_text_dark_pressed;
        public static int common_google_signin_btn_text_light = C0526R.color.common_google_signin_btn_text_light;
        public static int common_google_signin_btn_text_light_default = C0526R.color.common_google_signin_btn_text_light_default;
        public static int common_google_signin_btn_text_light_disabled = C0526R.color.common_google_signin_btn_text_light_disabled;
        public static int common_google_signin_btn_text_light_focused = C0526R.color.common_google_signin_btn_text_light_focused;
        public static int common_google_signin_btn_text_light_pressed = C0526R.color.common_google_signin_btn_text_light_pressed;
    }

    /* renamed from: com.android.support.R$drawable */
    public static final class C0125drawable {
        public static int app_icon = C0526R.C0527drawable.app_icon;
        public static int common_full_open_on_phone = C0526R.C0527drawable.common_full_open_on_phone;
        public static int common_google_signin_btn_icon_dark = C0526R.C0527drawable.common_google_signin_btn_icon_dark;
        public static int common_google_signin_btn_icon_dark_disabled = C0526R.C0527drawable.common_google_signin_btn_icon_dark_disabled;
        public static int common_google_signin_btn_icon_dark_focused = C0526R.C0527drawable.common_google_signin_btn_icon_dark_focused;
        public static int common_google_signin_btn_icon_dark_normal = C0526R.C0527drawable.common_google_signin_btn_icon_dark_normal;
        public static int common_google_signin_btn_icon_dark_pressed = C0526R.C0527drawable.common_google_signin_btn_icon_dark_pressed;
        public static int common_google_signin_btn_icon_light = C0526R.C0527drawable.common_google_signin_btn_icon_light;
        public static int common_google_signin_btn_icon_light_disabled = C0526R.C0527drawable.common_google_signin_btn_icon_light_disabled;
        public static int common_google_signin_btn_icon_light_focused = C0526R.C0527drawable.common_google_signin_btn_icon_light_focused;
        public static int common_google_signin_btn_icon_light_normal = C0526R.C0527drawable.common_google_signin_btn_icon_light_normal;
        public static int common_google_signin_btn_icon_light_pressed = C0526R.C0527drawable.common_google_signin_btn_icon_light_pressed;
        public static int common_google_signin_btn_text_dark = C0526R.C0527drawable.common_google_signin_btn_text_dark;
        public static int common_google_signin_btn_text_dark_disabled = C0526R.C0527drawable.common_google_signin_btn_text_dark_disabled;
        public static int common_google_signin_btn_text_dark_focused = C0526R.C0527drawable.common_google_signin_btn_text_dark_focused;
        public static int common_google_signin_btn_text_dark_normal = C0526R.C0527drawable.common_google_signin_btn_text_dark_normal;
        public static int common_google_signin_btn_text_dark_pressed = C0526R.C0527drawable.common_google_signin_btn_text_dark_pressed;
        public static int common_google_signin_btn_text_light = C0526R.C0527drawable.common_google_signin_btn_text_light;
        public static int common_google_signin_btn_text_light_disabled = C0526R.C0527drawable.common_google_signin_btn_text_light_disabled;
        public static int common_google_signin_btn_text_light_focused = C0526R.C0527drawable.common_google_signin_btn_text_light_focused;
        public static int common_google_signin_btn_text_light_normal = C0526R.C0527drawable.common_google_signin_btn_text_light_normal;
        public static int common_google_signin_btn_text_light_pressed = C0526R.C0527drawable.common_google_signin_btn_text_light_pressed;
        public static int default_image = C0526R.C0527drawable.default_image;
        public static int fyt = C0526R.C0527drawable.fyt;
        public static int ic_account_box_black = C0526R.C0527drawable.ic_account_box_black;
        public static int ic_event_black = C0526R.C0527drawable.ic_event_black;
        public static int ic_visibility_black = C0526R.C0527drawable.ic_visibility_black;
        public static int quot = C0526R.C0527drawable.quot;
    }

    /* renamed from: com.android.support.R$id */
    public static final class C0126id {
        public static int adjust_height = C0526R.C0528id.adjust_height;
        public static int adjust_width = C0526R.C0528id.adjust_width;
        public static int auto = C0526R.C0528id.auto;
        public static int button1 = C0526R.C0528id.button1;
        public static int button2 = C0526R.C0528id.button2;
        public static int button3 = C0526R.C0528id.button3;
        public static int button4 = C0526R.C0528id.button4;
        public static int checkbox1 = C0526R.C0528id.checkbox1;
        public static int checkbox2 = C0526R.C0528id.checkbox2;
        public static int clss = C0526R.C0528id.clss;
        public static int dark = C0526R.C0528id.dark;
        public static int edittext1 = C0526R.C0528id.edittext1;
        public static int edittext2 = C0526R.C0528id.edittext2;
        public static int edittext3 = C0526R.C0528id.edittext3;
        public static int edittext4 = C0526R.C0528id.edittext4;
        public static int edittext5 = C0526R.C0528id.edittext5;
        public static int finalsub = C0526R.C0528id.finalsub;
        public static int icon_only = C0526R.C0528id.icon_only;
        public static int imageview1 = C0526R.C0528id.imageview1;
        public static int imageview2 = C0526R.C0528id.imageview2;
        public static int light = C0526R.C0528id.light;
        public static int linear1 = C0526R.C0528id.linear1;
        public static int linear12 = C0526R.C0528id.linear12;
        public static int linear13 = C0526R.C0528id.linear13;
        public static int linear14 = C0526R.C0528id.linear14;
        public static int linear15 = C0526R.C0528id.linear15;
        public static int linear2 = C0526R.C0528id.linear2;
        public static int linear3 = C0526R.C0528id.linear3;
        public static int linear4 = C0526R.C0528id.linear4;
        public static int linear5 = C0526R.C0528id.linear5;
        public static int linear6 = C0526R.C0528id.linear6;
        public static int linear7 = C0526R.C0528id.linear7;
        public static int linear8 = C0526R.C0528id.linear8;
        public static int linear9 = C0526R.C0528id.linear9;
        public static int listview1 = C0526R.C0528id.listview1;
        public static int none = C0526R.C0528id.none;
        public static int refill = C0526R.C0528id.refill;
        public static int save = C0526R.C0528id.save;
        public static int spinner1 = C0526R.C0528id.spinner1;
        public static int standard = C0526R.C0528id.standard;
        public static int textview1 = C0526R.C0528id.textview1;
        public static int textview10 = C0526R.C0528id.textview10;
        public static int textview11 = C0526R.C0528id.textview11;
        public static int textview12 = C0526R.C0528id.textview12;
        public static int textview13 = C0526R.C0528id.textview13;
        public static int textview14 = C0526R.C0528id.textview14;
        public static int textview15 = C0526R.C0528id.textview15;
        public static int textview16 = C0526R.C0528id.textview16;
        public static int textview17 = C0526R.C0528id.textview17;
        public static int textview18 = C0526R.C0528id.textview18;
        public static int textview2 = C0526R.C0528id.textview2;
        public static int textview3 = C0526R.C0528id.textview3;
        public static int textview4 = C0526R.C0528id.textview4;
        public static int textview5 = C0526R.C0528id.textview5;
        public static int textview6 = C0526R.C0528id.textview6;
        public static int textview7 = C0526R.C0528id.textview7;
        public static int textview8 = C0526R.C0528id.textview8;
        public static int textview9 = C0526R.C0528id.textview9;
        public static int vscroll2 = C0526R.C0528id.vscroll2;
        public static int webview1 = C0526R.C0528id.webview1;
        public static int webview2 = C0526R.C0528id.webview2;
        public static int wide = C0526R.C0528id.wide;
    }

    /* renamed from: com.android.support.R$integer */
    public static final class integer {
        public static int google_play_services_version = C0526R.integer.google_play_services_version;
    }

    /* renamed from: com.android.support.R$layout */
    public static final class layout {
        public static int apply = C0526R.layout.apply;
        public static int coustm = C0526R.layout.coustm;
        public static int flash = C0526R.layout.flash;
        public static int form = C0526R.layout.form;
        public static int fsubmit = C0526R.layout.fsubmit;
        public static int login = C0526R.layout.login;
        public static int main = C0526R.layout.main;
        public static int signup = C0526R.layout.signup;
    }

    /* renamed from: com.android.support.R$string */
    public static final class string {
        public static int common_google_play_services_enable_button = C0526R.string.common_google_play_services_enable_button;
        public static int common_google_play_services_enable_text = C0526R.string.common_google_play_services_enable_text;
        public static int common_google_play_services_enable_title = C0526R.string.common_google_play_services_enable_title;
        public static int common_google_play_services_install_button = C0526R.string.common_google_play_services_install_button;
        public static int common_google_play_services_install_text = C0526R.string.common_google_play_services_install_text;
        public static int common_google_play_services_install_title = C0526R.string.common_google_play_services_install_title;
        public static int common_google_play_services_notification_ticker = C0526R.string.common_google_play_services_notification_ticker;
        public static int common_google_play_services_unknown_issue = C0526R.string.common_google_play_services_unknown_issue;
        public static int common_google_play_services_unsupported_text = C0526R.string.common_google_play_services_unsupported_text;
        public static int common_google_play_services_update_button = C0526R.string.common_google_play_services_update_button;
        public static int common_google_play_services_update_text = C0526R.string.common_google_play_services_update_text;
        public static int common_google_play_services_update_title = C0526R.string.common_google_play_services_update_title;
        public static int common_google_play_services_updating_text = C0526R.string.common_google_play_services_updating_text;
        public static int common_google_play_services_wear_update_text = C0526R.string.common_google_play_services_wear_update_text;
        public static int common_open_on_phone = C0526R.string.common_open_on_phone;
        public static int common_signin_button_text = C0526R.string.common_signin_button_text;
        public static int common_signin_button_text_long = C0526R.string.common_signin_button_text_long;
        public static int firebase_database_url = C0526R.string.firebase_database_url;
        public static int google_api_key = C0526R.string.google_api_key;
        public static int google_app_id = C0526R.string.google_app_id;
        public static int project_id = C0526R.string.project_id;
    }

    /* renamed from: com.android.support.R$style */
    public static final class style {
        public static int AppTheme = C0526R.style.AppTheme;
        public static int FullScreen = C0526R.style.FullScreen;
        public static int NoActionBar = C0526R.style.NoActionBar;
    }

    /* renamed from: com.android.support.R$styleable */
    public static final class styleable {
        public static final int[] LoadingImageView = {C0526R.attr.imageAspectRatioAdjust, C0526R.attr.imageAspectRatio, C0526R.attr.circleCrop};
        public static int LoadingImageView_circleCrop = 2;
        public static int LoadingImageView_imageAspectRatio = 1;
        public static int LoadingImageView_imageAspectRatioAdjust = 0;
        public static final int[] SignInButton = {C0526R.attr.buttonSize, C0526R.attr.colorScheme, C0526R.attr.scopeUris};
        public static int SignInButton_buttonSize = 0;
        public static int SignInButton_colorScheme = 1;
        public static int SignInButton_scopeUris = 2;
    }
}
