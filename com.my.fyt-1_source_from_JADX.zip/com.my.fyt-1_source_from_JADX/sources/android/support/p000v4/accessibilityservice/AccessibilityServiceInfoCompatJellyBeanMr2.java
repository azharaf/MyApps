package android.support.p000v4.accessibilityservice;

import android.accessibilityservice.AccessibilityServiceInfo;

/* renamed from: android.support.v4.accessibilityservice.AccessibilityServiceInfoCompatJellyBeanMr2 */
class AccessibilityServiceInfoCompatJellyBeanMr2 {
    AccessibilityServiceInfoCompatJellyBeanMr2() {
    }

    public static int getCapabilities(AccessibilityServiceInfo info) {
        return info.getCapabilities();
    }
}
