package android.support.p000v4.print;

import android.content.Context;

/* renamed from: android.support.v4.print.PrintHelperApi20 */
class PrintHelperApi20 extends PrintHelperKitkat {
    PrintHelperApi20(Context context) {
        super(context);
        this.mPrintActivityRespectsOrientation = false;
    }
}
