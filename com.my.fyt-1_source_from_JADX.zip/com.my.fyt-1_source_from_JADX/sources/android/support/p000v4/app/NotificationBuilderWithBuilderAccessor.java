package android.support.p000v4.app;

import android.app.Notification;
import android.app.Notification.Builder;

/* renamed from: android.support.v4.app.NotificationBuilderWithBuilderAccessor */
public interface NotificationBuilderWithBuilderAccessor {
    Notification build();

    Builder getBuilder();
}
