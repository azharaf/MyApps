package android.support.p000v4.p002os;

import android.os.Parcelable.Creator;

/* renamed from: android.support.v4.os.ParcelableCompatCreatorHoneycombMR2Stub */
/* compiled from: ParcelableCompatHoneycombMR2 */
class ParcelableCompatCreatorHoneycombMR2Stub {
    ParcelableCompatCreatorHoneycombMR2Stub() {
    }

    static <T> Creator<T> instantiate(ParcelableCompatCreatorCallbacks<T> callbacks) {
        return new ParcelableCompatCreatorHoneycombMR2(callbacks);
    }
}
