package android.support.p000v4.view;

import android.view.MotionEvent;

/* renamed from: android.support.v4.view.MotionEventCompatICS */
class MotionEventCompatICS {
    MotionEventCompatICS() {
    }

    public static int getButtonState(MotionEvent event) {
        return event.getButtonState();
    }
}
