package android.support.p000v4.view;

import android.view.View;

/* renamed from: android.support.v4.view.OnApplyWindowInsetsListener */
public interface OnApplyWindowInsetsListener {
    WindowInsetsCompat onApplyWindowInsets(View view, WindowInsetsCompat windowInsetsCompat);
}
