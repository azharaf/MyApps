package android.support.p000v4.view;

import android.view.View;

/* renamed from: android.support.v4.view.ViewPropertyAnimatorUpdateListener */
public interface ViewPropertyAnimatorUpdateListener {
    void onAnimationUpdate(View view);
}
