package android.support.p000v4.content;

import android.content.Intent;

/* renamed from: android.support.v4.content.IntentCompatIcsMr1 */
class IntentCompatIcsMr1 {
    IntentCompatIcsMr1() {
    }

    public static Intent makeMainSelectorActivity(String selectorAction, String selectorCategory) {
        return Intent.makeMainSelectorActivity(selectorAction, selectorCategory);
    }
}
