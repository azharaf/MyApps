package android.support.p000v4.content.p001pm;

/* renamed from: android.support.v4.content.pm.ActivityInfoCompat */
public final class ActivityInfoCompat {
    public static final int CONFIG_UI_MODE = 512;

    private ActivityInfoCompat() {
    }
}
