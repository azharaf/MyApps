package android.support.p000v4.internal.view;

import android.view.SubMenu;

/* renamed from: android.support.v4.internal.view.SupportSubMenu */
public interface SupportSubMenu extends SupportMenu, SubMenu {
}
